<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ecopay extends Model
{
    //


}
