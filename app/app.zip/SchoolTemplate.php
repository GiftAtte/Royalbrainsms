<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SchoolTemplate extends Model
{protected $fillable=[ 'school_id','template_id'];//
}
