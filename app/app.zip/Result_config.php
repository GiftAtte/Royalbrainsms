<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Result_config extends Model
{
    //
}
