<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FeeItem extends Model
{
    protected $fillable=[ 'school_id','name'];
}
