<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ReportTemplate extends Model
{
     
     protected $fillable=['report_id','template_id','school_id'];
}
