<?php

namespace App\Models\Livestream;

use Illuminate\Database\Eloquent\Model;

class Meeting extends Model
{
    //
}
