<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AdmissionLevel extends Model
{
       protected $fillable=['name','school_id'];
}
