<template>
    <div>
<div class="card-body">
                <div class="chart">
                  <div class="chartjs-size-monitor">
                  <div class="chartjs-size-monitor-shrink">
                  <div class=""></div>
                  </div>
                  <div class="chartjs-size-monitor-expand">
                  <div class=""></div>
                  </div></div>
                  <canvas id="stackedBarChart" style="height: 230px; min-height: 230px; display: block; width: 341px;" width="341" height="230" class="chartjs-render-monitor">
                  </canvas>
                </div>
              </div>
    </div>
</template>

<script lang="ts">
    import Vue from 'vue'

    export default Vue.extend({
        
    })
</script>

<style scoped>

</style>