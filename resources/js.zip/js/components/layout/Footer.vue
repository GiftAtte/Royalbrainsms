<template>

   <footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
     A Smart World
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; 2020 <a href="https://thinkschoolapp.com">ThinkSkul Technology</a>.</strong> All rights reserved.
    </footer>

</template>

<script>
    

    export default {
        
    }
</script>

<style scoped>

</style>