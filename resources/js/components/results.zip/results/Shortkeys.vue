<template>
  <table class="table table-bordered table-sm font-weight-bold  table-striped " width="100%" >
 <tr >
 <th colspan="2"  class="text-uppercase text-center text-bold text-primary">Short Keys</th>
 </tr>

 <tbody>

 <tr>
 <td>CA</td><td>Continuous Assessment</td>
 </tr>
 <tr>
 <td>CS Position</td><td>Class Subject Position</td>
 </tr>
 <tr>
 <td>SH Score</td><td>Subject Highest Score</td>
 </tr>
 <tr>
 <td>SL Score</td><td>Subject Lowest Score</td>
 </tr>
 <tr>
 <td>CSA Score<td>Class Subject Avg. Score</td>
 </tr>

 <tr>
 <td>AS Position</td><td>Arm Subject Position</td>
 </tr>
 <tr>
 <td>ASL Score</td><td>Arm Subject Lowest Score</td>
 </tr>
 <tr>
 <td>ASH Score</td><td>Arm Subject Highest Score</td>
 </tr>
 <tr>
 <td>ASA Score</td><td>Arm Subject Average Score</td>
 </tr>


 </tbody>
 </table>

</template>

<script>
export default {

}
</script>

<style>

</style>