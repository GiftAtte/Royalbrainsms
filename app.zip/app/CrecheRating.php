<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CrecheRating extends Model
{
    protected $fillable=[
        'rate','school_id'
    ];
}
