<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CrecheDomain extends Model
{
    protected $fillable=[
        'name','school_id'
    ];
}
